#include <iostream>

using namespace std;

int main()
{
    //kamus
    //int a=10;

    //while]
    /*while(a<20){
        cout<<"nilai a : "<<a<<endl;
        a++;
    }*/

    //do while
    /*do{
       cout<<"nilai a do while : "<<a<<endl;
       a++2;
       }while(a<101);
*/
       //for
       /*for (int a=1; a>100; a+=2){
            cout<<"nilai a : "<<a<<endl;
       }*/

        /*for(;;){
            cout<<"aaaa"<<endl;
        }*/

    return 0;
}
