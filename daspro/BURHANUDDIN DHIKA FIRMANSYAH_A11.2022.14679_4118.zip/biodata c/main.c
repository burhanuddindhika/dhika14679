#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("BIODATA\n");
printf("========================================\n");
printf("\n");
printf("NAMA    : BURHANUDDIN DHIKA FIRMANSYAH\n");
printf("NIM     : A11.2022.14679\n");
printf("ALAMAT  : DEMAK\n");
printf("TTL     : DEMAK 30-10-2004\n");
printf("HOBI    : REBAHAN\n");
printf("\n");
printf("========================================\n");
return 0;
}
