#include <iostream>

using namespace std;

int main()
{
    int random
    random = RAND()

    cout << random <<endl
}